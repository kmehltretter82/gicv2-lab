/Users/kmehltretter/codex/linux-work/gicv2-lab/build/2026-09-05-h6-frozen/image/src/exception.o: \
  src/exception.c include/gicv2_lab/exception.h \
  include/gicv2_lab/gicv2.h include/gicv2_lab/gicv2_defs.h \
  include/gicv2_lab/hvc.h include/gicv2_lab/layout.h \
  include/gicv2_lab/platform.h include/gicv2_lab/print.h
include/gicv2_lab/exception.h:
include/gicv2_lab/gicv2.h:
include/gicv2_lab/gicv2_defs.h:
include/gicv2_lab/hvc.h:
include/gicv2_lab/layout.h:
include/gicv2_lab/platform.h:
include/gicv2_lab/print.h:
