/Users/kmehltretter/codex/linux-work/gicv2-lab/build/2026-09-05-h6-frozen/image/src/main.o: \
  src/main.c include/gicv2_lab/gicv2.h include/gicv2_lab/gicv2_defs.h \
  include/gicv2_lab/layout.h include/gicv2_lab/platform.h \
  include/gicv2_lab/print.h include/gicv2_lab/stage2.h \
  include/gicv2_lab/uart.h include/gicv2_lab/watchdog.h
include/gicv2_lab/gicv2.h:
include/gicv2_lab/gicv2_defs.h:
include/gicv2_lab/layout.h:
include/gicv2_lab/platform.h:
include/gicv2_lab/print.h:
include/gicv2_lab/stage2.h:
include/gicv2_lab/uart.h:
include/gicv2_lab/watchdog.h:
