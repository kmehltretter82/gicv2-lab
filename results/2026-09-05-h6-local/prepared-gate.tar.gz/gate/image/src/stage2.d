/Users/kmehltretter/codex/linux-work/gicv2-lab/build/2026-09-05-h6-frozen/image/src/stage2.o: \
  src/stage2.c include/gicv2_lab/gicv2_defs.h include/gicv2_lab/layout.h \
  include/gicv2_lab/stage2.h
include/gicv2_lab/gicv2_defs.h:
include/gicv2_lab/layout.h:
include/gicv2_lab/stage2.h:
