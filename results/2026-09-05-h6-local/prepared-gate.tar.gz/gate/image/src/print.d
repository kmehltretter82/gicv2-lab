/Users/kmehltretter/codex/linux-work/gicv2-lab/build/2026-09-05-h6-frozen/image/src/print.o: \
  src/print.c include/gicv2_lab/print.h include/gicv2_lab/uart.h
include/gicv2_lab/print.h:
include/gicv2_lab/uart.h:
