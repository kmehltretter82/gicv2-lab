/Users/kmehltretter/codex/linux-work/gicv2-lab/build/2026-09-05-h6-frozen/image/src/watchdog.o: \
  src/watchdog.c include/gicv2_lab/platform.h \
  include/gicv2_lab/gicv2_defs.h include/gicv2_lab/watchdog.h
include/gicv2_lab/platform.h:
include/gicv2_lab/gicv2_defs.h:
include/gicv2_lab/watchdog.h:
