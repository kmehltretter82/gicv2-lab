set -eu
session=/home/karl/gicv2-lab-20260905-hardware
out="$session/kut-prerequisite-manual"
mkdir "$out"
mkdir "$out/logs"
cd "$session/kvm-unit-tests"
git diff HEAD --exit-code
git rev-parse HEAD > "$out/source-commit.txt"
git archive HEAD | gzip > "$out/source.tar.gz"
cp arm/gic.flat config.mak arm/unittests.cfg "$out/"
uname -a > "$out/host.txt"
gcc --version > "$out/compiler-version.txt"
qemu-system-aarch64 --version > "$out/qemu-version.txt"
sha256sum /usr/bin/qemu-system-aarch64 /usr/bin/gcc arm/gic.flat config.mak arm/unittests.cfg > "$out/SHA256SUMS"
set +e
sudo -n runuser -u karl -g kvm -- env ACCEL=kvm QEMU=/usr/bin/qemu-system-aarch64 MACHINE=virt TIMEOUT=30s unittest_log_dir="$out/logs" timeout --kill-after=5s 120s ./run_tests.sh -v gicv2-mmio-up > "$out/unit-tests.log" 2>&1
status=$?
printf '%s\n' "$status" > "$out/exit-status.txt"
cat "$out/unit-tests.log"
exit "$status"
