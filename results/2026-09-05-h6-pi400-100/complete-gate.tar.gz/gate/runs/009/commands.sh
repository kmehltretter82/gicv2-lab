ssh -o ConnectTimeout=10 -o BatchMode=yes karl@192.168.1.15 true 
ssh -o ConnectTimeout=10 -o BatchMode=yes karl@192.168.1.15 sha256sum\ --\ /boot/firmware/gicv2-lab-h6.bin 
ssh -o ConnectTimeout=10 -o BatchMode=yes karl@192.168.1.15 uname\ -a\ \&\&\ cat\ /proc/cpuinfo\ \&\&\ vcgencmd\ version 
ssh -o ConnectTimeout=10 -o BatchMode=yes karl@192.168.1.15 cat\ /boot/firmware/tryboot.txt 
ssh -o ConnectTimeout=10 -o BatchMode=yes karl@192.168.1.15 sudo\ reboot\ \'0\ tryboot\' 
stty 115200 cs8 -parenb -cstopb raw -echo; exec cat < /dev/cu.usbserial-B0043XBS > /Users/kmehltretter/codex/linux-work/gicv2-lab/build/2026-09-05-pi400-hardware/h6/gate/runs/009/serial.log
